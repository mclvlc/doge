# doge：原作者是37tt，这里是一份改版
## 你想要做我的乖狗狗吗？

这个是汤汤表白网站的小狗版，点击不要按钮会跑的那种，原版网站作者为37tt（抖音@汤汤好梦），由于原版网站作者号被封了所以原仓库就放一个我自己fork的原版。👉👉👉[https://mclvlc.github.io/tang-love/](https://mclvlc.github.io/tang-love/ "是跳转到网页的链接！")<br>
# 以下是我的改版网站
部署了github page，可通过 👉👉👉[https://mclvlc.github.io/doge/](https://mclvlc.github.io/doge/ "是跳转到网页的链接！") 访问！<br>

![doge的演示效果](https://mclvlc.github.io/doge/doge.gif "doge的演示效果")
